public class CableRepair extends ITSolution {

    public CableRepair() {
        super("Cable Repair Solution");

    }

    @Override
    public void implementSolution() {
        System.out.println("Repairing and maintaining cables...");

    }
    
}
