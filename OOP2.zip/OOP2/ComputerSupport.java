public class ComputerSupport extends ITSolution {

    public ComputerSupport() {
        super("Computer Support Solution");
        
    }

    @Override
    public void implementSolution() {
        System.out.println("Providing computer support and troubleshooting...");

    }

}