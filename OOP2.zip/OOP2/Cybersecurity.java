public class Cybersecurity extends Security {

    public Cybersecurity() {
        super();
        solutionName = "Cybersecurity Solution";
        
    }

    @Override
    public void implementSolution() {
        super.implementSolution();
        System.out.println("Implementing additional cybersecurity measures...");

    }

}