public abstract class ITSolution {
    protected String solutionName;

    public ITSolution(String solutionName) {
        this.solutionName = solutionName;
        
    }

    public abstract void implementSolution();

    public void displaySolutionInfo() {
        System.out.println("Solution: " + solutionName);
    }
}