import java.util.Scanner;


public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Select an IT solution:");
        System.out.println("1. Security Solution");
        System.out.println("2. Cable Repair Solution");
        System.out.println("3. Computer Support Solution");
        System.out.println("4. Wifi Installation Solution");
        System.out.println("5. Cybersecurity Solution");
        System.out.println("6. Repair Services Solution");

        System.out.print("Enter the number of the solution you want to implement: ");
        int choice = scanner.nextInt();

        ITSolution selectedSolution = null;
//Applying Polymorphism and Inheritance
        switch (choice) {

            case 1:
                selectedSolution = new Security();
                break;
            case 2:
                selectedSolution = new CableRepair();
                break;
            case 3:
                selectedSolution = new ComputerSupport();
                break;
            case 4:
                selectedSolution = new WifiInstallation();
                break;  
            case 5:
                selectedSolution = new Cybersecurity();
                break;
            case 6:
                selectedSolution = new Repair();
                break;
            default:
                System.out.println("Invalid choice.");
                break;

        }
//This is where we apply abstraction
        if (selectedSolution != null) {
            selectedSolution.displaySolutionInfo();
            selectedSolution.implementSolution();
        }

        scanner.close(); //And here we apply Encapsulation by closing scanner.

    }

}
