public class Repair extends ITSolution {
    
    public Repair() {
        super("Repair Services Solution");

    }

    @Override
    public void implementSolution() {
        System.out.println("Providing general repair services for IT equipment...");

    }

}