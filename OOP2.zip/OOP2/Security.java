public class Security extends ITSolution {

    public Security() {
        super("Security Solution");

    }

    @Override
    public void implementSolution() {
        System.out.println("Implementing security measures...");

    }

    public void applySecurityMeasures() {
        System.out.println("Applying security measures specific to Security Solution...");

    }
    
}