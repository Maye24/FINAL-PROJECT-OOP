public class WifiInstallation extends ITSolution {

    public WifiInstallation() {
        super("Wifi Installation Solution");
        
    }

    @Override
    public void implementSolution() {
        System.out.println("Installing and configuring WiFi networks...");

    }

}